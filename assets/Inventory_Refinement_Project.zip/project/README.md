# Inventory Organizer with AI-Assisted Administration (Refined Version)

IT 497 Capstone — Project Refinement and Ethical Integration

## What this is

This is a refined version of my freelance Inventory Organizer / AI-Enhanced
Data Administration project. The original version (built earlier this
semester) tracked inventory and used simple automation to flag low stock.
This refinement keeps the same core purpose but adds the technical and
ethical safeguards documented in `REFINEMENT_REPORT.docx`.

## Running it

```
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000 in a browser.

**Demo logins:**
- `admin` / `admin123` — full access (can approve AI suggestions, view the audit log, export identifying data)
- `staff` / `staff123` — can view inventory and run AI analysis, but cannot approve suggestions or export identifying data

A `test_smoke.py` script is included and exercises every major flow
(login, role restrictions, AI suggestion approval, audit logging, and
both export modes). Run it with `python test_smoke.py`.

## What changed, in one paragraph

The original project applied automation directly to inventory without any
review step, had no access control or audit trail, and exported all data
(including client references) the same way regardless of who asked for it.
This version adds a human-in-the-loop approval queue for every AI
suggestion, role-based access control, full audit logging, explainable
(rule-based, not black-box) suggestions with plain-language rationale, and
a privacy-conscious export flow that anonymizes data by default. See
`REFINEMENT_REPORT.docx` for the full breakdown of each challenge, the
ethical reasoning behind each fix, and its impact.

## Scalability note (beyond this classroom demo)

This demo uses SQLite and loads a small, paginated item list, which is
fine for a few hundred items. For a real multi-client deployment, the
next steps would be: migrating to PostgreSQL, adding per-client database
scoping or row-level security, and moving the AI suggestion job to a
background worker (e.g., Celery) so it doesn't run in the request/response
cycle as inventory volume grows.
