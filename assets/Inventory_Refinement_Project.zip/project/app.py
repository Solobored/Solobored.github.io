"""
Inventory Organizer with AI-Assisted Administration (Refined Version)
----------------------------------------------------------------------
IT 497 Capstone — Project Refinement and Ethical Integration

This is a refined version of a freelance inventory management project,
enhanced with AI-assisted reorder suggestions AND a set of ethical and
technical safeguards that were missing from the original version:

  1. Human-in-the-loop approval  - AI never changes inventory on its own.
     Every suggestion sits in a review queue until a named, logged-in
     person approves or rejects it.
  2. Role-based access control    - "staff" and "admin" roles exist.
     Approving AI suggestions and exporting identifiable data requires
     the admin role, so automated actions are always traceable to an
     accountable person.
  3. Full audit logging           - every login, item change, AI
     suggestion, and approval/rejection is time-stamped and attributed.
  4. Explainable suggestions      - each AI suggestion includes a plain
     -language rationale and a confidence indicator, not just a number.
  5. Privacy-conscious export     - CSV exports are anonymized by
     default; exporting full identifying detail requires an admin to
     type a logged justification first.
  6. Basic security hardening     - all queries are parameterized
     (no string-built SQL), passwords are hashed, and inputs are
     validated server-side.
  7. Accessibility improvements   - semantic HTML, labelled form
     fields, and an ARIA live region for status messages.
  8. Scalability starting point   - list views are paginated instead
     of loading the whole table at once (see README for the larger
     scalability plan beyond this demo).

Run with:  python app.py
Then visit http://127.0.0.1:5000  (demo logins: admin/admin123, staff/staff123)
"""

import sqlite3
import datetime
import io
import csv
from functools import wraps

from flask import (
    Flask, g, request, session, redirect, url_for, render_template_string,
    flash, Response
)
from werkzeug.security import generate_password_hash, check_password_hash

APP_SECRET = "dev-secret-change-me"  # NOTE: replace with a real secret in production
DB_PATH = "inventory.db"
PAGE_SIZE = 5
LOW_STOCK_MULTIPLIER = 1.0  # suggest reorder when qty <= reorder_threshold

app = Flask(__name__)
app.secret_key = APP_SECRET


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','staff'))
        );

        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            client_ref TEXT,              -- potentially identifying business/client note
            quantity INTEGER NOT NULL,
            reorder_threshold INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS suggestions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id INTEGER NOT NULL,
            suggested_qty INTEGER NOT NULL,
            confidence TEXT NOT NULL,
            rationale TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
            reviewed_by TEXT,
            reviewed_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(item_id) REFERENCES items(id)
        );

        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT
        );
        """
    )
    # Seed demo data only if empty
    cur = db.execute("SELECT COUNT(*) AS c FROM users")
    if cur.fetchone()["c"] == 0:
        db.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
            ("admin", generate_password_hash("admin123"), "admin"),
        )
        db.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
            ("staff", generate_password_hash("staff123"), "staff"),
        )
        demo_items = [
            ("Shipping boxes (medium)", "Client: Northline Goods", 42, 20),
            ("Barcode labels (roll)", "Client: Northline Goods", 8, 15),
            ("Packing tape", "Client: Cordero Hardware", 3, 10),
            ("Warehouse gloves (pair)", "Client: Cordero Hardware", 60, 25),
            ("Pallet wrap (roll)", "Client: Aguilar Foods", 5, 12),
            ("Thermal printer ribbon", "Client: Aguilar Foods", 30, 10),
        ]
        db.executemany(
            "INSERT INTO items (name, client_ref, quantity, reorder_threshold) VALUES (?,?,?,?)",
            demo_items,
        )
        db.commit()
    db.close()


def log_action(actor, action, details=""):
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (ts, actor, action, details) VALUES (?,?,?,?)",
        (datetime.datetime.now().isoformat(timespec="seconds"), actor, action, details),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("username"):
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("That action requires an administrator account.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# "AI-assisted" reorder logic
# ---------------------------------------------------------------------------
# NOTE ON HONESTY / EXPLAINABILITY:
# This is deliberately a transparent, rule-based heuristic rather than a
# black-box model. Every suggestion states in plain language *why* it was
# made. This is an intentional ethical choice: a small business owner
# should be able to understand and question a recommendation about their
# own inventory, not just trust a number.

def generate_ai_suggestions(actor):
    db = get_db()
    items = db.execute("SELECT * FROM items").fetchall()
    created = 0
    for item in items:
        if item["quantity"] <= item["reorder_threshold"] * LOW_STOCK_MULTIPLIER:
            existing = db.execute(
                "SELECT id FROM suggestions WHERE item_id=? AND status='pending'",
                (item["id"],),
            ).fetchone()
            if existing:
                continue  # don't duplicate a suggestion still awaiting human review

            deficit = item["reorder_threshold"] - item["quantity"]
            suggested_qty = max(deficit + item["reorder_threshold"], 5)
            gap_ratio = item["quantity"] / max(item["reorder_threshold"], 1)
            if gap_ratio <= 0.3:
                confidence = "High"
            elif gap_ratio <= 0.7:
                confidence = "Medium"
            else:
                confidence = "Low"

            rationale = (
                f"Current stock ({item['quantity']}) is at or below the reorder "
                f"threshold ({item['reorder_threshold']}). Suggesting a restock of "
                f"{suggested_qty} units to return above threshold with a buffer. "
                f"This is a rule-based estimate, not a guarantee — please confirm "
                f"against real demand before approving."
            )

            db.execute(
                """INSERT INTO suggestions
                   (item_id, suggested_qty, confidence, rationale, status, created_at)
                   VALUES (?,?,?,?,?,?)""",
                (item["id"], suggested_qty, confidence, rationale, "pending",
                 datetime.datetime.now().isoformat(timespec="seconds")),
            )
            created += 1
    db.commit()
    log_action(actor, "AI_ANALYSIS_RUN", f"{created} new suggestion(s) generated")
    return created


# ---------------------------------------------------------------------------
# Templates (kept inline for a single-file demo; see README for structure notes)
# ---------------------------------------------------------------------------

BASE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ title }} · Inventory Admin</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 900px; margin: 30px auto; padding: 0 16px; color: #1a1a1a; }
  nav { display:flex; gap:16px; border-bottom:1px solid #ddd; padding-bottom:10px; margin-bottom:20px; flex-wrap:wrap;}
  nav a { text-decoration:none; color:#2b4a47; font-weight:600; }
  table { border-collapse: collapse; width:100%; margin-top:12px; }
  th, td { border:1px solid #ddd; padding:8px; text-align:left; font-size:0.95rem;}
  th { background:#f2f4f3; }
  .low { background:#fde8e8; }
  .badge { padding:2px 8px; border-radius:3px; font-size:0.8rem; }
  .badge-high { background:#fde2e2; color:#8a1c1c; }
  .badge-medium { background:#fff3cd; color:#7a5b00; }
  .badge-low { background:#e2f0d9; color:#2c5b1e; }
  form.inline { display:inline; }
  .msg { padding:10px; border-radius:4px; margin-bottom:14px; }
  .msg.error { background:#fde2e2; color:#8a1c1c; }
  .msg.success { background:#e2f0d9; color:#2c5b1e; }
  .note { color:#555; font-size:0.9rem; }
  fieldset { margin-top:16px; }
  label { display:block; margin-top:8px; font-weight:600; }
  input, select, textarea { padding:6px; width:100%; max-width:320px; margin-top:2px; }
  button { margin-top:12px; padding:8px 14px; cursor:pointer; }
</style>
</head>
<body>
<nav aria-label="Main navigation">
  <a href="{{ url_for('dashboard') }}">Dashboard</a>
  {% if session.get('username') %}
    <a href="{{ url_for('suggestions') }}">AI Suggestions</a>
    {% if session.get('role') == 'admin' %}<a href="{{ url_for('audit') }}">Audit Log</a>{% endif %}
    <a href="{{ url_for('export') }}">Export report</a>
    <span class="note">Logged in as {{ session.get('username') }} ({{ session.get('role') }})</span>
    <a href="{{ url_for('logout') }}">Log out</a>
  {% else %}
    <a href="{{ url_for('login') }}">Log in</a>
  {% endif %}
</nav>
<div role="status" aria-live="polite">
{% with messages = get_flashed_messages(with_categories=true) %}
  {% for category, message in messages %}
    <div class="msg {{ category }}">{{ message }}</div>
  {% endfor %}
{% endwith %}
</div>
{{ body|safe }}
</body>
</html>
"""


def render(title, body):
    return render_template_string(BASE, title=title, body=render_template_string(body))


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["username"] = user["username"]
            session["role"] = user["role"]
            log_action(username, "LOGIN_SUCCESS")
            flash("Logged in successfully.", "success")
            return redirect(url_for("dashboard"))
        log_action(username or "(unknown)", "LOGIN_FAILED")
        flash("Invalid username or password.", "error")
    body = """
    <h1>Log in</h1>
    <p class="note">Demo accounts — admin / admin123 (full access) or staff / staff123 (view + run AI analysis only).</p>
    <form method="post" novalidate>
      <label for="username">Username</label>
      <input id="username" name="username" required>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" required>
      <button type="submit">Log in</button>
    </form>
    """
    return render("Log in", body)


@app.route("/logout")
def logout():
    if session.get("username"):
        log_action(session["username"], "LOGOUT")
    session.clear()
    flash("Logged out.", "success")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def dashboard():
    db = get_db()
    page = max(int(request.args.get("page", 1)), 1)
    offset = (page - 1) * PAGE_SIZE
    items = db.execute(
        "SELECT * FROM items ORDER BY name LIMIT ? OFFSET ?", (PAGE_SIZE, offset)
    ).fetchall()
    total = db.execute("SELECT COUNT(*) AS c FROM items").fetchone()["c"]
    has_next = offset + PAGE_SIZE < total
    has_prev = page > 1

    rows = ""
    for item in items:
        low = item["quantity"] <= item["reorder_threshold"]
        rows += f"""<tr class="{'low' if low else ''}">
            <td>{item['name']}</td>
            <td>{item['quantity']}</td>
            <td>{item['reorder_threshold']}</td>
            <td>{'⚠ Low stock' if low else 'OK'}</td>
        </tr>"""

    body = f"""
    <h1>Inventory dashboard</h1>
    <p class="note">Showing page {page} of items (paginated, {PAGE_SIZE} per page — see README for the larger scalability plan).</p>
    <table>
      <tr><th>Item</th><th>Qty on hand</th><th>Reorder threshold</th><th>Status</th></tr>
      {rows}
    </table>
    <p>
      {"<a href='?page=" + str(page-1) + "'>&laquo; Previous</a>" if has_prev else ""}
      {" &nbsp; " if has_prev and has_next else ""}
      {"<a href='?page=" + str(page+1) + "'>Next &raquo;</a>" if has_next else ""}
    </p>
    <form method="post" action="{url_for('run_analysis')}">
      <button type="submit">Run AI stock analysis</button>
    </form>
    <p class="note">This scans inventory and creates suggestions for human review — it never changes stock levels on its own.</p>
    """
    return render("Dashboard", body)


@app.route("/run-analysis", methods=["POST"])
@login_required
def run_analysis():
    created = generate_ai_suggestions(session["username"])
    if created:
        flash(f"AI analysis complete: {created} new suggestion(s) added to the review queue.", "success")
    else:
        flash("AI analysis complete: no new suggestions (nothing new below threshold).", "success")
    return redirect(url_for("suggestions"))


@app.route("/suggestions")
@login_required
def suggestions():
    db = get_db()
    rows = db.execute(
        """SELECT s.*, i.name as item_name, i.quantity as current_qty
           FROM suggestions s JOIN items i ON s.item_id = i.id
           ORDER BY s.status = 'pending' DESC, s.created_at DESC"""
    ).fetchall()

    html_rows = ""
    for s in rows:
        badge_class = {"High": "badge-high", "Medium": "badge-medium", "Low": "badge-low"}[s["confidence"]]
        actions = ""
        if s["status"] == "pending":
            if session.get("role") == "admin":
                actions = f"""
                <form class="inline" method="post" action="{url_for('review_suggestion', suggestion_id=s['id'], decision='approve')}">
                  <button type="submit">Approve</button>
                </form>
                <form class="inline" method="post" action="{url_for('review_suggestion', suggestion_id=s['id'], decision='reject')}">
                  <button type="submit">Reject</button>
                </form>
                """
            else:
                actions = "<span class='note'>Awaiting admin review</span>"
        else:
            actions = f"{s['status'].title()} by {s['reviewed_by']} at {s['reviewed_at']}"

        html_rows += f"""<tr>
          <td>{s['item_name']}</td>
          <td>{s['current_qty']}</td>
          <td>+{s['suggested_qty']}</td>
          <td><span class="badge {badge_class}">{s['confidence']}</span></td>
          <td class="note">{s['rationale']}</td>
          <td>{actions}</td>
        </tr>"""

    body = f"""
    <h1>AI reorder suggestions</h1>
    <p class="note">Every suggestion requires a named admin to approve or reject it before inventory changes. Nothing here is applied automatically.</p>
    <table>
      <tr><th>Item</th><th>Current qty</th><th>Suggested +qty</th><th>Confidence</th><th>Rationale</th><th>Action</th></tr>
      {html_rows if html_rows else "<tr><td colspan='6'>No suggestions yet — run an AI stock analysis from the dashboard.</td></tr>"}
    </table>
    """
    return render("AI Suggestions", body)


@app.route("/suggestions/<int:suggestion_id>/<decision>", methods=["POST"])
@login_required
@admin_required
def review_suggestion(suggestion_id, decision):
    if decision not in ("approve", "reject"):
        flash("Invalid decision.", "error")
        return redirect(url_for("suggestions"))

    db = get_db()
    s = db.execute("SELECT * FROM suggestions WHERE id=?", (suggestion_id,)).fetchone()
    if not s or s["status"] != "pending":
        flash("That suggestion is no longer pending.", "error")
        return redirect(url_for("suggestions"))

    now = datetime.datetime.now().isoformat(timespec="seconds")
    new_status = "approved" if decision == "approve" else "rejected"
    db.execute(
        "UPDATE suggestions SET status=?, reviewed_by=?, reviewed_at=? WHERE id=?",
        (new_status, session["username"], now, suggestion_id),
    )
    if decision == "approve":
        db.execute(
            "UPDATE items SET quantity = quantity + ? WHERE id=?",
            (s["suggested_qty"], s["item_id"]),
        )
    db.commit()
    log_action(
        session["username"],
        f"SUGGESTION_{new_status.upper()}",
        f"suggestion #{suggestion_id} for item #{s['item_id']}",
    )
    flash(f"Suggestion {new_status}.", "success")
    return redirect(url_for("suggestions"))


@app.route("/audit")
@login_required
@admin_required
def audit():
    db = get_db()
    rows = db.execute("SELECT * FROM audit_log ORDER BY ts DESC LIMIT 100").fetchall()
    html_rows = "".join(
        f"<tr><td>{r['ts']}</td><td>{r['actor']}</td><td>{r['action']}</td><td>{r['details'] or ''}</td></tr>"
        for r in rows
    )
    body = f"""
    <h1>Audit log</h1>
    <p class="note">Every login, AI analysis run, and suggestion decision is recorded here for accountability.</p>
    <table>
      <tr><th>Time</th><th>Actor</th><th>Action</th><th>Details</th></tr>
      {html_rows}
    </table>
    """
    return render("Audit log", body)


@app.route("/export", methods=["GET", "POST"])
@login_required
def export():
    if request.method == "POST":
        justification = request.form.get("justification", "").strip()
        include_full = request.form.get("include_full") == "on"
        if include_full and session.get("role") != "admin":
            flash("Only an admin can export identifying client detail.", "error")
            return redirect(url_for("export"))
        if include_full and not justification:
            flash("A justification is required to export identifying client detail.", "error")
            return redirect(url_for("export"))

        db = get_db()
        items = db.execute("SELECT * FROM items").fetchall()
        buf = io.StringIO()
        writer = csv.writer(buf)
        if include_full:
            writer.writerow(["Item", "Client reference", "Quantity", "Reorder threshold"])
            for i in items:
                writer.writerow([i["name"], i["client_ref"], i["quantity"], i["reorder_threshold"]])
            log_action(session["username"], "EXPORT_FULL", justification)
        else:
            writer.writerow(["Item", "Quantity", "Reorder threshold"])
            for i in items:
                writer.writerow([i["name"], i["quantity"], i["reorder_threshold"]])
            log_action(session["username"], "EXPORT_ANONYMIZED")

        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment; filename=inventory_export.csv"},
        )

    is_admin = session.get("role") == "admin"
    body = f"""
    <h1>Export report</h1>
    <p class="note">By default, exports are anonymized (no client-identifying data). {"As an admin, you may include full detail below, but you must record why." if is_admin else "Client-identifying exports require an admin account."}</p>
    <form method="post">
      {"<fieldset><label><input type='checkbox' name='include_full'> Include client-identifying detail</label><label for='justification'>Justification (required if including full detail)</label><textarea id='justification' name='justification' rows='2'></textarea></fieldset>" if is_admin else ""}
      <button type="submit">Download CSV</button>
    </form>
    """
    return render("Export", body)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
