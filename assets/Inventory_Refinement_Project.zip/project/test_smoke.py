import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

# Fresh DB each test run
if os.path.exists("inventory.db"):
    os.remove("inventory.db")

import app as appmod  # noqa: E402

appmod.init_db()
client = appmod.app.test_client()

def login(username, password):
    return client.post("/login", data={"username": username, "password": password}, follow_redirects=True)

print("== Anonymous dashboard should redirect to login ==")
r = client.get("/", follow_redirects=True)
assert b"Log in" in r.data
print("OK")

print("== Bad login ==")
r = login("admin", "wrongpass")
assert b"Invalid username or password" in r.data
print("OK")

print("== Staff login ==")
r = login("staff", "staff123")
assert b"Inventory dashboard" in r.data
print("OK")

print("== Staff can run AI analysis ==")
r = client.post("/run-analysis", follow_redirects=True)
assert b"AI analysis complete" in r.data
print("OK")

print("== Staff cannot approve suggestions (no admin actions visible) ==")
r = client.get("/suggestions")
assert b"Awaiting admin review" in r.data
assert b">Approve<" not in r.data
print("OK")

print("== Staff cannot view audit log ==")
r = client.get("/audit", follow_redirects=True)
assert b"requires an administrator account" in r.data
print("OK")

client.get("/logout", follow_redirects=True)

print("== Admin login and approve a suggestion ==")
r = login("admin", "admin123")
assert b"Inventory dashboard" in r.data

r = client.get("/suggestions")
assert b"Approve" in r.data

# find a pending suggestion id from DB directly for a deterministic test
import sqlite3
con = sqlite3.connect("inventory.db")
con.row_factory = sqlite3.Row
pending = con.execute("SELECT * FROM suggestions WHERE status='pending' LIMIT 1").fetchone()
assert pending is not None, "expected at least one pending suggestion"
item_before = con.execute("SELECT quantity FROM items WHERE id=?", (pending["item_id"],)).fetchone()["quantity"]
con.close()

r = client.post(f"/suggestions/{pending['id']}/approve", follow_redirects=True)
assert b"Suggestion approved" in r.data
print("OK")

print("== Approving updates inventory quantity ==")
con = sqlite3.connect("inventory.db")
con.row_factory = sqlite3.Row
item_after = con.execute("SELECT quantity FROM items WHERE id=?", (pending["item_id"],)).fetchone()["quantity"]
con.close()
assert item_after > item_before, f"expected quantity to increase ({item_before} -> {item_after})"
print(f"OK ({item_before} -> {item_after})")

print("== Audit log recorded the approval ==")
r = client.get("/audit")
assert b"SUGGESTION_APPROVED" in r.data
assert b"LOGIN_FAILED" in r.data
print("OK")

print("== Anonymized export works for anyone ==")
r = client.post("/export", data={}, follow_redirects=True)
assert r.mimetype == "text/csv"
assert b"Client reference" not in r.data
print("OK")

print("== Full export requires justification ==")
r = client.post("/export", data={"include_full": "on"}, follow_redirects=True)
assert b"justification is required" in r.data
print("OK")

print("== Full export works with justification (admin) ==")
r = client.post("/export", data={"include_full": "on", "justification": "Client requested full ledger for reconciliation"}, follow_redirects=True)
assert r.mimetype == "text/csv"
assert b"Client reference" in r.data
print("OK")

print("\nALL SMOKE TESTS PASSED")
